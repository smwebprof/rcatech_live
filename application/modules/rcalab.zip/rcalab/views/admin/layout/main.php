<?php echo $this->load->view('admin/layout/header'); ?>
	
<?php 
	  echo $this->load->view($layout_body); 
?>

<?php echo $this->load->view('admin/layout/footer'); ?>

